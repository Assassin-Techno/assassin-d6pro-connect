plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "de.assassin.d6connect"
    compileSdk = 35
    defaultConfig {
        applicationId = "de.assassin.d6connect"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.5.0"
    }
}
