package de.assassin.d6connect

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val adapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var list: LinearLayout
    private val seen = linkedMapOf<String, BluetoothDevice>()
    private val logLines = mutableListOf<String>()
    private var selectedDevice: BluetoothDevice? = null
    private var selectedName: String = "D6 PRO"
    private var reconnectAttempts = 0
    private val maxReconnectAttempts = 5
    private var userRequestedDisconnect = false
    private val handler = Handler(Looper.getMainLooper())
    private val pendingGattOps = ArrayDeque<() -> Unit>()
    private var gattOperationRunning = false
    private lateinit var telemetryView: TextView
    private lateinit var serviceView: TextView
    private val prefs by lazy { getSharedPreferences("d6connect", MODE_PRIVATE) }
    private val dateFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.GERMANY)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val saved = prefs.getString("log", "") ?: ""
        if (saved.isNotBlank()) {
            logLines.addAll(saved.split("\n").takeLast(1500))
            logView.text = logLines.takeLast(100).joinToString("\n")
        }
        requestBlePermissions()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(0xFF101318.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); setPadding(0, 8, 0, 8) }
        page.addView(label("ASSASSIN D6 PRO CONNECT", 22f))
        page.addView(label("BLE-Diagnose · Nur lesender Prototyp", 13f, 0xFF9AA4B2.toInt()))
        status = label("Status: nicht verbunden", 16f, 0xFF62D99A.toInt())
        page.addView(status)

        page.addView(label("LIVE-TELEMETRIE", 15f, 0xFF8FA8C8.toInt()))
        telemetryView = label(
            "Geschwindigkeit: —\nAkku: —\nSpannung: —\nStrom: —\nODO: —\nTRIP: —\nBMS: nicht verifiziert",
            16f, 0xFFE5EAF2.toInt()
        )
        page.addView(telemetryView)
        page.addView(label("Die Werte bleiben leer, bis das Controller-Protokoll sicher identifiziert ist.", 12f, 0xFFFFC66D.toInt()))

        val scan = Button(this).apply { text = "Bluetooth-Suche starten"; setOnClickListener { startScan() } }
        page.addView(scan)
        val reconnect = Button(this).apply {
            text = "Letztes Gerät erneut verbinden"
            setOnClickListener {
                val d = selectedDevice
                if (d == null) status.text = "Noch kein Gerät ausgewählt."
                else { reconnectAttempts = 0; userRequestedDisconnect = false; connect(d, selectedName) }
            }
        }
        page.addView(reconnect)
        page.addView(label("Gefundene Geräte – Scooter auswählen", 16f))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(list)
        page.addView(label("Erkannte Bluetooth-Dienste", 16f))
        serviceView = label("Noch keine Dienste erkannt.", 12f, 0xFFD5D9E0.toInt())
        page.addView(serviceView)
        page.addView(label("GATT-Rohdaten / Diagnoseprotokoll", 16f))
        logView = label("Noch keine Daten. Verbinde den Scooter.", 12f, 0xFFD5D9E0.toInt())
        page.addView(logView)
        val export = Button(this).apply { text = "Diagnoseprotokoll als TXT teilen"; setOnClickListener { shareLog() } }
        page.addView(export)
        val exportCsv = Button(this).apply { text = "Rohdaten als CSV teilen"; setOnClickListener { shareCsv() } }
        page.addView(exportCsv)
        page.addView(label("Hinweis: Dieser Prototyp sendet keine Steuerbefehle und verändert keine Scooter-Einstellungen.", 12f, 0xFFFFC66D.toInt()))
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun requestBlePermissions() {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 100)
    }

    private fun hasPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= 31)
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        else checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startScan() {
        if (!hasPermission()) { requestBlePermissions(); return }
        val a = adapter
        if (a == null || !a.isEnabled) { status.text = "Bluetooth ist ausgeschaltet."; return }
        seen.clear(); list.removeAllViews()
        scanner = a.bluetoothLeScanner
        status.text = "Suche läuft (12 Sekunden)…"
        try {
            scanner?.startScan(scanCallback)
            Handler(Looper.getMainLooper()).postDelayed({
                try { scanner?.stopScan(scanCallback) } catch (_: SecurityException) {}
                status.text = "Suche beendet – ${seen.size} Gerät(e) gefunden."
            }, 12000)
        } catch (e: SecurityException) { status.text = "Bluetooth-Berechtigung fehlt: ${e.message}" }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val key = device.address ?: return
            if (seen.containsKey(key)) return
            seen[key] = device
            runOnUiThread {
                val name = try { device.name ?: result.scanRecord?.deviceName ?: "Unbenanntes BLE-Gerät" }
                    catch (_: SecurityException) { "BLE-Gerät" }
                val button = Button(this@MainActivity).apply {
                    text = "$name  ·  RSSI ${result.rssi} dBm\n$key"
                    setOnClickListener { reconnectAttempts = 0; connect(device, name) }
                }
                list.addView(button)
                addLog("SCAN", "$name [$key], RSSI=${result.rssi}")
            }
        }
        override fun onScanFailed(errorCode: Int) { runOnUiThread { status.text = "Scan-Fehler: $errorCode" } }
    }

    private fun connect(device: BluetoothDevice, name: String) {
        if (!hasPermission()) { requestBlePermissions(); return }
        try {
            selectedDevice = device
            selectedName = name
            userRequestedDisconnect = false
            scanner?.stopScan(scanCallback)
            gatt?.close()
            gatt = null
            status.text = "Verbinde mit $name…"
            addLog("CONNECT", "Verbindungsversuch zu $name")
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            handler.postDelayed({
                if (gatt != null && status.text.toString().startsWith("Verbinde")) {
                    addLog("TIMEOUT", "Verbindungsaufbau dauert ungewöhnlich lange")
                    status.text = "Verbindung dauert zu lange. Erneut versuchen."
                }
            }, 15000)
        } catch (e: SecurityException) { status.text = "Verbindungsfehler: ${e.message}" }
    }

    private fun scheduleReconnect(reason: String) {
        if (userRequestedDisconnect || selectedDevice == null || reconnectAttempts >= maxReconnectAttempts) {
            status.text = "Verbindung getrennt. Manuelle Wiederverbindung möglich."
            return
        }
        reconnectAttempts++
        val delay = (reconnectAttempts * 3000L).coerceAtMost(15000L)
        status.text = "Verbindung verloren – neuer Versuch $reconnectAttempts/$maxReconnectAttempts"
        addLog("RECONNECT", "$reason; Versuch $reconnectAttempts in ${delay / 1000}s")
        handler.postDelayed({
            if (!userRequestedDisconnect && selectedDevice != null) {
                try {
                    gatt?.close()
                    gatt = null
                    val d = selectedDevice!!
                    gatt = d.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
                } catch (e: Exception) {
                    addLog("RECONNECT_ERROR", e.message ?: "unbekannter Fehler")
                    scheduleReconnect("Reconnect-Aufruf fehlgeschlagen")
                }
            }
        }, delay)
    }

    private fun enqueueGattOp(op: () -> Unit) {
        pendingGattOps.addLast(op)
        runNextGattOp()
    }

    private fun runNextGattOp() {
        if (gattOperationRunning || pendingGattOps.isEmpty()) return
        gattOperationRunning = true
        try {
            pendingGattOps.removeFirst().invoke()
        } catch (e: Exception) {
            gattOperationRunning = false
            addLog("GATT_QUEUE_ERROR", e.message ?: "Unbekannter Fehler")
            handler.post { runNextGattOp() }
        }
    }

    private fun finishGattOp() {
        gattOperationRunning = false
        handler.post { runNextGattOp() }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            runOnUiThread {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    status.text = "Verbunden – suche Dienste…"
                    handler.postDelayed({
                        if (gatt === g && newState == BluetoothProfile.STATE_CONNECTED) {
                            reconnectAttempts = 0
                            addLog("LINK_STABLE", "Verbindung mindestens 30 Sekunden gehalten")
                        }
                    }, 30000)
                    addLog("GATT", "Verbunden; starte Service Discovery")
                    if (hasPermission()) g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    addLog("GATT", "Verbindung getrennt; status=$statusCode")
                    try { g.close() } catch (_: Exception) {}
                    pendingGattOps.clear()
                    gattOperationRunning = false
                    if (gatt === g) gatt = null
                    scheduleReconnect("BLE-Verbindung getrennt, Status $statusCode")
                }
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                addLog("GATT", "Service Discovery Fehler $statusCode")
                return
            }
            pendingGattOps.clear()
            gattOperationRunning = false
            val serviceLines = mutableListOf<String>()
            g.services.forEach { service ->
                addLog("SERVICE", service.uuid.toString())
                serviceLines.add("SERVICE ${service.uuid}")
                service.characteristics.forEach { ch ->
                    val props = mutableListOf<String>()
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) props.add("READ")
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) props.add("WRITE")
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props.add("NOTIFY")
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) props.add("INDICATE")
                    val propText = props.joinToString(",")
                    addLog("CHAR", "${ch.uuid} [$propText]")
                    serviceLines.add("  ${ch.uuid} [$propText]")

                    // Read-only discovery: queue reads only for characteristics explicitly marked READ.
                    if (ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) {
                        enqueueGattOp {
                            val accepted = g.readCharacteristic(ch)
                            addLog("READ_REQUEST", "${ch.uuid}; accepted=$accepted")
                            if (!accepted) finishGattOp()
                        }
                    }

                    // Subscribe to telemetry notifications, without sending scooter control commands.
                    if (ch.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                        val cccd = ch.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
                        if (cccd != null) {
                            enqueueGattOp {
                                try {
                                    g.setCharacteristicNotification(ch, true)
                                    val descriptorValue =
                                        if (ch.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
                                            BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                                        else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                                    val accepted = if (Build.VERSION.SDK_INT >= 33) {
                                        g.writeDescriptor(cccd, descriptorValue) == BluetoothStatusCodes.SUCCESS
                                    } else {
                                        @Suppress("DEPRECATION")
                                        run {
                                            cccd.value = descriptorValue
                                            g.writeDescriptor(cccd)
                                        }
                                    }
                                    addLog("CCCD_REQUEST", "${ch.uuid}; accepted=$accepted")
                                    if (!accepted) finishGattOp()
                                } catch (e: Exception) {
                                    addLog("CCCD_ERROR", "${ch.uuid}: ${e.message}")
                                    finishGattOp()
                                }
                            }
                        }
                    }
                }
            }
            runOnUiThread {
                serviceView.text = serviceLines.joinToString("\n")
                status.text = "Verbunden – ${g.services.size} Dienst(e), GATT-Prüfung läuft."
            }
            if (pendingGattOps.isEmpty()) {
                runOnUiThread { status.text = "Verbunden – Dienste erkannt; keine lesbaren/benachrichtigenden Merkmale." }
            } else runNextGattOp()
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION")
            val bytes = ch.value ?: byteArrayOf()
            addLog("NOTIFY ${ch.uuid}", bytes.toHex())
            runOnUiThread { telemetryView.text = "Geschwindigkeit: nicht dekodiert\nAkku: nicht dekodiert\nSpannung: nicht dekodiert\nStrom: nicht dekodiert\nODO: nicht dekodiert\nTRIP: nicht dekodiert\nLetztes Paket: ${bytes.size} Byte" }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, ch: BluetoothGattCharacteristic, value: ByteArray) {
            addLog("NOTIFY ${ch.uuid}", value.toHex())
            runOnUiThread { telemetryView.text = "Geschwindigkeit: nicht dekodiert\nAkku: nicht dekodiert\nSpannung: nicht dekodiert\nStrom: nicht dekodiert\nODO: nicht dekodiert\nTRIP: nicht dekodiert\nLetztes Paket: ${value.size} Byte" }
        }
        override fun onCharacteristicRead(g: BluetoothGatt, ch: BluetoothGattCharacteristic, value: ByteArray, statusCode: Int) {
            addLog("READ ${ch.uuid}", "status=$statusCode ${value.toHex()}")
            finishGattOp()
        }
        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(g: BluetoothGatt, ch: BluetoothGattCharacteristic, statusCode: Int) {
            val bytes = ch.value ?: byteArrayOf()
            addLog("READ ${ch.uuid}", "status=$statusCode ${bytes.toHex()}")
            finishGattOp()
        }
        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            addLog("CCCD_RESULT", "${descriptor.characteristic.uuid}; status=$statusCode")
            finishGattOp()
        }
    }

    private fun ByteArray.toHex() = joinToString(" ") { "%02X".format(it) }

    private fun addLog(tag: String, value: String) {
        val line = "${dateFmt.format(Date())} [$tag] $value"
        runOnUiThread {
            logLines.add(line)
            if (logLines.size > 1500) logLines.removeAt(0)
            logView.text = logLines.takeLast(100).joinToString("\n")
        }
    }

    private fun shareLog() {
        val text = logLines.joinToString("\n")
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "D6 PRO BLE Diagnose"); putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Diagnoseprotokoll teilen"))
    }

    private fun shareCsv() {
        val rows = mutableListOf("timestamp;type;data")
        logLines.forEach { line ->
            val match = Regex("^(.*?) \\[(.*?)\\] (.*)$").find(line)
            if (match != null) {
                val timestamp = match.groupValues[1]
                val type = match.groupValues[2].replace(";", ",")
                val data = match.groupValues[3].replace(";", ",")
                rows.add("$timestamp;$type;$data")
            }
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "D6 PRO BLE Rohdaten CSV")
            putExtra(Intent.EXTRA_TEXT, rows.joinToString("\n"))
        }
        startActivity(Intent.createChooser(intent, "CSV-Diagnose teilen"))
    }

    override fun onDestroy() {
        userRequestedDisconnect = true
        handler.removeCallbacksAndMessages(null)
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
